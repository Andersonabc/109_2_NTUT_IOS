//
//  GameResult.swift
//  practice_MVVM
//
//  Created by 李承紘 on 2021/5/19.
//

import Foundation
enum GameResult {
    case win
    case lose
    case tie
}
