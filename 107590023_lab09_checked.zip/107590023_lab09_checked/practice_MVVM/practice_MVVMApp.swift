//
//  practice_MVVMApp.swift
//  practice_MVVM
//
//  Created by 李承紘 on 2021/5/19.
//

import SwiftUI

@main
struct practice_MVVMApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
