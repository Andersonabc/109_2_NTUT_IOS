//
//  SwiftUICoursesApp.swift
//  SwiftUICourses
//
//  Created by 李承紘 on 2021/4/26.
//

import SwiftUI

@main
struct SwiftUICoursesApp: App {
    var body: some Scene {
        WindowGroup {
            mainView().preferredColorScheme(/*@START_MENU_TOKEN@*/.dark/*@END_MENU_TOKEN@*/)
        }
    }
}
